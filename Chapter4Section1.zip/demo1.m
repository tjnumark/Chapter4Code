% demo1.m
% preprocess and plot extracted feature
% read flac file
% wma format transform is from 
%   https://audio.worthsee.com/convert
%
% Mark @ TNU 20230901
%

% 清空 workspace
clear; close all; clc;

% load a test signal
[audioIn, fs] = audioread('onetwothree.flac');

% transform 2 channel to 1 channel
audioIn = sum(audioIn, 2) / 2;

% loacate the speech area in the signal
boundaries = detectSpeech(audioIn, fs);

for i1 = 1:size(boundaries, 1)
    audioIni1 = audioIn(boundaries(i1,1):boundaries(i1,2));

    % plot audio
    figure(i1); subplot(2,1,1); hold on;
    plot(audioIni1);
    axis tight; box on; grid on; hold off;

    % extract features
    features = helperExtractAuditoryFeatures(audioIni1,fs);

    % plot features
    hold on; subplot(2,1,2);
    pcolor(features');
    shading flat
    hold off;
    drawnow;
end

  
