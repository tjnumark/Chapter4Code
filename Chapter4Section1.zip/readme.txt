20230901
# The code works find on version R2022b.

# Revision 1
weightedClassificationLayer.m is removed in R2022b.

# dataset---speech_commands_v0.01
it is easy to download from url
https://storage.googleapis.com/download.tensorflow.org/data/speech_commands_v0.01.tar.gz
extract files of dataset to the same folder as demo2.m with folder name 'speech_commands_v0.01'

# Code reference
Speech Command Recognition Using Deep Learning, Matlab.
https://ww2.mathworks.cn/help/releases/R2019b/audio/examples/Speech-Command-Recognition-Using-Deep-Learning.html

