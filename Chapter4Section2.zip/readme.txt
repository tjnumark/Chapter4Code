20230901
# Test demos in Chapter4 Section2.
# demo4.m和demo5.m可以直接运行，运行demo6.m需要dataset

# zh-CN dataset can be downloaded from
https://commonvoice.mozilla.org/zh-CN/datasets
or
链接：https://pan.baidu.com/s/1bpFEQ5K45oC7nwzg5OTZww?pwd=ziro 
提取码：ziro

# 解压dataset里的zh-CN文件夹到当前工作目录，
zh-CN文件夹中包含的文件列表如下：
--- clips文件夹
--- dev.tsv
--- invalidated.tsv
--- other.tsv
--- reported.tsv
--- test.tsv
--- train.tsv
--- validated.tsv

# Code reference
Classify Gender Using LSTM Networks
https://ww2.mathworks.cn/help/releases/R2019b/audio/examples/classify-gender-using-long-short-term-memory-networks.html


