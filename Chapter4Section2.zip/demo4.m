% demo4.m
% Preprocess Audio Data to get feature vectors
% Reference
%   R2020a Classify Gender Using LSTM Networks
% 

% 清空工作空间
clear; clc; close all;
[audioIn,Fs] = audioread('common_voice_zh-CN_18531551.mp3');
% [audioIn,Fs] = audioread('maleSpeech.flac');
labels = {'male'};
% Plot the audio signal
timeVector = (1/Fs) * (0:size(audioIn,1)-1);
figure(1); subplot(2,1,1);
plot(timeVector,audioIn)
ylabel("Amplitude")
xlabel("Time (s)")
title("Sample Audio")
grid on; hold on; box on;
% listen to it using the sound command
% sound(audioIn,Fs)
% locate segments of speech in the audio signal
speechIndices = detectSpeech(audioIn,Fs);
% Create an audioFeatureExtractor to extract features from the audio data
extractor = audioFeatureExtractor( ...
    "SampleRate",Fs, ...
    "Window",hamming(round(0.03*Fs),"periodic"), ...
    "OverlapLength",round(0.02*Fs), ...
    "pitch",true);
featureVectorsSegment = {};
for ii = 1:size(speechIndices,1)
    featureVectorsSegment{end+1} = ( extract(extractor,audioIn(speechIndices(ii,1):speechIndices(ii,2))) )';
end
% ----- check array size
numSegments = size(featureVectorsSegment);
pitchFeatureVector = [];
for i1 = 1:numSegments(2)
    pitchFeatureVector = [pitchFeatureVector, featureVectorsSegment{i1}];
end
subplot(2,1,2);
plot(pitchFeatureVector)
ylabel('Pitch')
xlabel('Number of features')
grid on; box on; hold off;



