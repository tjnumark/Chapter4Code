% demo5.m
% Classify Gender with a Pre-Trained Network
%   genderIDNet_zhCN_MFCC.mat
% accuracy = 74%
% 

% 清空工作空间
clear; close all; clc

% Load the pre-trained network along with pre-computed vectors 
% used for feature normalization
matFileName = fullfile('genderIDNet_zhCN_MFCC.mat');
load(matFileName,'net','M','S');

% Load a test signal with a male speaker
[audioIn,Fs] = audioread('common_voice_zh-CN_18531551.mp3');
% sound(audioIn,Fs);

% Isolate the speech area in the signal.
boundaries = detectSpeech(audioIn,Fs);
audioIn = audioIn(boundaries(1):boundaries(2));

extractor = audioFeatureExtractor( ...
    "SampleRate",Fs, ...
    "Window",hamming(round(0.03*Fs),"periodic"), ...
    "OverlapLength",round(0.02*Fs), ...
    'mfcc',true); 

% Extract features from the signal and normalize them.
features = extract(extractor,audioIn);
features = (features.' - M)./S;
% Classify the signal
gender = classify(net,features);

